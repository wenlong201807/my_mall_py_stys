# 用户名在cookie中的过期时间
USERNAME_COOKIE_EXPIRES = 60 * 60 * 24 * 14
# 激活邮箱的有效时间
EMAIL_ACTIVE_EXPIRES = 60 * 60 * 2
