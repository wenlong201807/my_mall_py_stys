# cookie中购物车的过期时间
CART_COOKIE_EXPIRES = 60 * 60 * 24 * 7
