# 图片验证码在redis中的过期时间，单位是秒
IMAGE_CODE_EXPIRES = 60 * 5
# 短信验证码在redis中的过期时间
SMS_CODE_EXPIRES = 60 * 5
# 短信验证码频繁发送的过期时间
SMS_CODE_FLAG = 60
