# 配置pymysql作为mysql的驱动
import pymysql
pymysql.install_as_MySQLdb()