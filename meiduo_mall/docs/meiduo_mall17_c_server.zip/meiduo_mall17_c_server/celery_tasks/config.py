#1, 任务队列
broker_url = 'redis://127.0.0.1:6379/14'

#2, 结果队列
result_backend = 'redis://127.0.0.1:6379/15'