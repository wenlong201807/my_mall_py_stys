from django.apps import AppConfig


class PaysConfig(AppConfig):
    name = 'pays'
